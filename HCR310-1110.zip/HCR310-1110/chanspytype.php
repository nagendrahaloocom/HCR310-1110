<?php
$number = $_REQUEST['number'];
$ext = $_REQUEST['extension'];
$caller = $_REQUEST['agentnum'];


include_once("/home/common/db_connect.php");

$query = mysqli_query($conn,"select uniqid,confnum from call_log where agent='$caller' order by id desc limit 1");
$rows = mysqli_fetch_array($query);
$call_uniq = $rows['uniqid'];
$confnum = $rows['confnum'];

$context = array('710'=>'chanspy','711'=>'chanwhisper','712'=>'chanbarge');
$spytype = $context[$ext];
mysqli_query($conn,"insert into callbarge_log(mdialtime,spytype,mnumber,call_uniqid)values(now(),'$spytype','$number','$call_uniq')");

$query2 = mysqli_query($conn,"select max(id) as uniq from callbarge_log where mnumber='$number'");
$rows2 = mysqli_fetch_array($query2);
$uniqid = $rows2['uniq'];


/*$c = exec('/usr/sbin/asterisk -rx "dahdi show version" |grep DAHDI');

if($c==''){
        $channel = 'SIP/gsm222/';
        }else{
        $a = exec('/usr/sbin/asterisk -rx "pri show spans" | grep Up');
        $bb = exec('/usr/sbin/asterisk -rx "pri show spans" | grep Alarm');
if(($a=='')||($bb!=''))
        {
        $channel = 'SIP/gsm222/';}
        else{
        $channel = 'DAHDI/g0/';}
        }
$channel = "SIP/67589210/".$number;*/ 
if(strlen($number)<5){$channel = 'SIP/'.$number;}else{$channel = 'SIP/JIO1/'.$number;}


        $uniq = uniqid();
        $uniq1 = "/tmp/".$uniq.".call";
$myfile =  fopen($uniq1,"w");

                fwrite($myfile,"channel:$channel\n");
                 fwrite($myfile,"context:$context[$ext]\n");
                fwrite($myfile,"waittime:45\n");
                fwrite($myfile,"extension:$ext\n");
                fwrite($myfile,"Setvar:callid=$caller\n");
                fwrite($myfile,"Setvar:confnum=$confnum\n");
                  fwrite($myfile,"Setvar:uniqid=$uniqid\n");
                fwrite($myfile,"Setvar:ext=$ext\n");
                fclose($myfile);

                system("/bin/mv $uniq1 /var/spool/asterisk/outgoing");
                echo "Your Request has been Initiated successfully.|".$uniqid;

?>
