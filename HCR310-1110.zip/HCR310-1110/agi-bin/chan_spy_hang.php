#!/usr/bin/php
<?php
include_once("phpagi-2.20/phpagi.php");
$AGI = new AGI();


$uniq = $argv[1];
$hcause = $argv[2];
$disposition = $argv[3];
$recordfile = $argv[4].".wav";
$rec = str_replace("monitor","MP3",$argv[4]).".mp3";


include_once("/home/common/db_connect.php");
$query = "select mchannel from callbarge_log where id='$uniq'";
$query1 = mysqli_query($conn,$query);

                $rows = mysqli_fetch_array($query1);
                $mleg = $rows['mchannel'];

$AGI->verbose("++++++++++++++++$mleg++++++++++");

system("/usr/sbin/asterisk -rx 'channel request hangup $mleg'");




$query ="update callbarge_log set mendtime=now(),mtotalduration=time_to_sec(timediff(mendtime,mdialtime)),mduration=time_to_sec(timediff(mendtime,mstarttime)),mdisposition='$disposition',mcausecode='$hcause' where id='$uniq'";
exec("/usr/bin/logger -p local4.info $fname $uniq $query");
mysqli_query($conn,$query);

?>

