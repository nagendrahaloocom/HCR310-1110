#!/usr/bin/php
<?php
include_once("phpagi-2.20/phpagi.php");
$AGI = new AGI();


$uniq   =   $argv[1];
$channel = $argv[2];
$ext = $argv[3];
$confnum = $argv[4];
$calluniq = $argv[5];
include_once("/home/common/db_connect.php");



$query = "update callbarge_log set mstarttime=now(),mchannel='$channel',mdisposition='ANSWERED' where id = '$uniq'";
mysqli_query($conn,$query);

        $AGI->set_variable("uniq","$uniq");

?>

